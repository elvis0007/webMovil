// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:
  {
    apiKey: "AIzaSyAEpzCMqzHWsBsxf84wa4R2dv6QRsVOaVk",
    authDomain: "finanzas-app-6ea9d.firebaseapp.com",
    projectId: "finanzas-app-6ea9d",
    storageBucket: "finanzas-app-6ea9d.firebasestorage.app",
    messagingSenderId: "289886218198",
    appId: "1:289886218198:web:d741241f71e1b452c9a677",
    measurementId: "G-3R87LJ6LBL"

  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
