import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-chip',
  templateUrl: './category-chip.component.html',
  styleUrls: ['./category-chip.component.scss'],
  standalone: false
})
export class CategoryChipComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
