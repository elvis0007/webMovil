import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balance-card',
  templateUrl: './balance-card.component.html',
  styleUrls: ['./balance-card.component.scss'],
  standalone: false
})
export class BalanceCardComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
